WhereInTheWorld
===============

This repo contains my work for the WhereInTheWorld Assignment.
I discussed this assignment heavily with Ming as he helped me
work out many of the errors I was having during setup.

I spent approximately 7 hours working on this assignment.
