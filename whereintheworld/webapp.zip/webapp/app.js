// Express initialization
var requestify = require('requestify')
var express = require('express');
var bodyParser = require('body-parser')
var app = express();
app.use(bodyParser.urlencoded())
app.use(bodyParser.json())

// Mongo initialization, setting up a connection to a MongoDB  (on Heroku or localhost)
var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://localhost/comp20'; // comp20 is the name of the database we are using in MongoDB
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
  db = databaseConnection;
});

app.get('/', function (request, response) {
  response.set('Content-Type', 'text/html');
  var responseBody = "<h1>Locations</h1>";
  db.collection('locations', function(error, collection) {
    collection.find({}).sort({'created_at': -1}).toArray(function(error, documents) {
      documents.forEach(function(doc) {
        var docString = "<p>Login: " + doc.login + " Lat: " + doc.lat + " Lng: " + doc.lng + " Created at: " + doc.created_at + "</p>";
        responseBody += docString;
      });
      response.send(responseBody);
    })
  })
});

app.get('/locations.json', function(request, response) {
  var login = request.query['login']
  response.set('Content-Type', 'text/json');
  if (login == undefined) {
    var empty = [];
    response.send(JSON.stringify(empty));
  } else {
    db.collection('locations', function (error, collection) {
      collection.find({'login' : login}).sort({'created_at': -1}).toArray(function(error, documents) {
        response.send(documents);
      })
    })
  }
});

app.post('/sendLocation', function (request, response) {
    response.header("Access-Control-Allow-Origin", "*");
    response.header("Access-Control-Allow-Headers", "X-Requested-With");

    var login = request.body.login
    var lat = request.body.lat;
    var lng = request.body.lng;
    var created_at = new Date();

    if (login != undefined && lat != undefined && lng != undefined) {
      db.collection('locations', function(error, collection) {
        collection.insert({'login': login, 'lat': lat, 'lng': lng, 'created_at': created_at}, function(error, saved) {});
      });
    }

    var resp = {};
    resp.characters = [];

    db.collection('locations', function(error, collection) {
      collection.find({}).sort({'created_at': -1}).limit(100).toArray(function(error, documents) {
      resp.students = documents;
      response.set('Content-Type', 'text/json');
      response.send(JSON.stringify(resp));
    })})
})

app.get('/redline.json', function(request, response) {
    response.header("Access-Control-Allow-Origin", "*");
    response.header("Access-Control-Allow-Headers", "X-Requested-With");
    requestify.get('http://developer.mbta.com/lib/rthr/red.json')
    .then(function(resp) {
      response.send(resp.getBody());
    })

})

// Oh joy! http://stackoverflow.com/questions/15693192/heroku-node-js-error-web-process-failed-to-bind-to-port-within-60-seconds-of
app.listen(process.env.PORT || 3000);